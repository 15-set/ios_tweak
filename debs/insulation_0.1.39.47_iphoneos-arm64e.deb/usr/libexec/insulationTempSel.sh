#!/bin/sh
# insulationTempSel: 把面板里单选式的温度开关同步为 ChargeLimiter 的数字阈值
# 动态补偿停充延迟：按实时升温速度取 3/4/5℃，停充更接近用户设定温度
COMP=4

SEL=/var/mobile/Library/Preferences/com.be-huge.thermalsel.plist
CONF=/var/mobile/Library/Preferences/com.chargelimiter.mod.plist
LOG=/var/mobile/Library/Preferences/insulationTempSel.log
LOCK=/tmp/tempsel.lock
XML=/tmp/tempsel.xml
T0F=/tmp/tempsel_t0
RATE10=8

mkdir "$LOCK" 2>/dev/null || exit 0
trap 'rmdir "$LOCK" 2>/dev/null' EXIT INT TERM HUP

log() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') $*" >> "$LOG" 2>/dev/null
}

pick() {
  pre="$1"; lo="$2"; hi="$3"
  i="$lo"
  while [ "$i" -le "$hi" ]; do
    k="${pre}_${i}"
    if grep -A1 "<key>$k</key>" "$XML" 2>/dev/null | grep -q "<true/>"; then
      echo "$i"; return 0
    fi
    if command -v defaults >/dev/null 2>&1; then
      v=$(defaults read "$SEL" "$k" 2>/dev/null)
      case "$v" in 1|true|YES) echo "$i"; return 0;; esac
    fi
    i=$((i + 1))
  done
  return 1
}

readint() {
  v=$(grep -A1 "<key>$2</key>" "$1" 2>/dev/null | sed -n 's:.*<integer>\([0-9]*\)</integer>.*:\1:p')
  if [ -z "$v" ] && command -v defaults >/dev/null 2>&1; then
    v=$(defaults read "$1" "$2" 2>/dev/null)
  fi
  [ -n "$v" ] || v="$3"
  echo "$v"
}

read_temp10() {
  v=$(ioreg -r -n AppleSmartBattery -w0 2>/dev/null | sed -n 's/.*"Temperature" = \([0-9][0-9]*\).*/\1/p' | head -n 1)
  [ -n "$v" ] || return 0
  [ "$v" -gt 0 ] 2>/dev/null || return 0
  echo "$v"
}

fmt10() {
  v="$1"
  if [ "$v" -lt 0 ]; then
    a=$((-v))
    echo "-$((a / 10)).$((a % 10))"
  else
    echo "$((v / 10)).$((v % 10))"
  fi
}

compute_rate() {
  cur10="$1"
  now=$(date +%s)
  if [ -f "$T0F" ]; then
    read -r ts t10 < "$T0F" 2>/dev/null
    if [ -n "$ts" ] && [ -n "$t10" ]; then
      el=$((now - ts))
      if [ "$el" -ge 30 ]; then
        RATE10=$(((cur10 - t10) * 60 / el))
        printf '%s %s\n' "$now" "$cur10" > "$T0F"
      fi
    fi
  else
    printf '%s %s\n' "$now" "$cur10" > "$T0F"
  fi
}

comp_for() {
  if [ "$1" -ge 15 ]; then
    COMP=5
  elif [ "$1" -ge 8 ]; then
    COMP=4
  else
    COMP=3
  fi
}

write_conf() {
  cat > "$CONF.tmp" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
<key>enable_temp</key><integer>1</integer>
<key>charge_temp_above</key><integer>$1</integer>
<key>charge_temp_below</key><integer>$2</integer>
<key>charge_above</key><integer>100</integer>
<key>charge_below</key><integer>0</integer>
</dict>
</plist>
EOF
  mv -f "$CONF.tmp" "$CONF" 2>/dev/null || rm -f "$CONF.tmp"
  chown mobile:mobile "$CONF" 2>/dev/null
  chmod 644 "$CONF" 2>/dev/null
}

while :; do
  temp10=$(read_temp10)
  if [ -z "$temp10" ]; then
    sleep 2
    continue
  fi
  compute_rate "$temp10"
  comp_for "$RATE10"
  if [ -f "$SEL" ]; then
    if command -v plutil >/dev/null 2>&1; then
      plutil -convert xml1 -o "$XML" "$SEL" 2>/dev/null || cp -f "$SEL" "$XML" 2>/dev/null
    else
      cp -f "$SEL" "$XML" 2>/dev/null
    fi
    up=$(pick t 41 47)
    dn=$(pick b 36 42)
    if [ -n "$up" ] || [ -n "$dn" ]; then
      cu=$(readint "$CONF" charge_temp_above 43)
      cd=$(readint "$CONF" charge_temp_below 40)
      nu=${up:-$cu}
      nd=${dn:-$cd}
      wh=$((nu - COMP))
      [ "$wh" -ge 1 ] || wh=1
      [ "$wh" -gt "$nd" ] || wh=$((nd + 1))
      if [ "$wh" != "$cu" ] || [ "$nd" != "$cd" ]; then
        write_conf "$wh" "$nd"
        log "t=$(fmt10 "$temp10") rate=$(fmt10 "$RATE10") comp=$COMP user_high=$nu -> write=$wh below=$nd"
        killall ChargeLimiter 2>/dev/null
      fi
    fi
  fi
  sleep 2
done
